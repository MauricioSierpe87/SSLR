from django.db import models

class IaapsIndicador(models.Model):
    anio = models.IntegerField()
    establecimiento = models.CharField(max_length=100)
    indicador = models.CharField(max_length=200)
    cumplimiento = models.DecimalField(max_digits=5, decimal_places=2)

    def estado(self):
        if self.cumplimiento >= 90:
            return 'verde'
        elif self.cumplimiento >= 75:
            return 'amarillo'
        else:
            return 'rojo'

    def __str__(self):
        return f"{self.indicador} - {self.establecimiento} ({self.anio})"