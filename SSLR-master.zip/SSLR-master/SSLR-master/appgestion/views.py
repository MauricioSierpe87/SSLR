from django.shortcuts import render
from django.http import HttpResponse
import csv
from .models import IaapsIndicador
from django.db.models import Q

def index(request):
    return render(request, 'index.html')

def comges(request):
    return render(request, 'comges.html')  



def exportar_comges(request):
    response = HttpResponse(content_type='text/csv')
    response['Content-Disposition'] = 'attachment; filename="comges.csv"'

    writer = csv.writer(response)
    writer.writerow(['Año', 'Establecimiento', 'Meta', 'Cumplimiento'])

    # Aquí puedes poner datos reales desde tu modelo
    writer.writerow([2024, 'Hospital X', 'Meta 1', '85%'])
    writer.writerow([2024, 'CESFAM Y', 'Meta 2', '92%'])

    return response

def metas_sanitarias(request):
    datos = [
        {'anio': 2024, 'establecimiento': 'Hospital Regional', 'meta': 'Cobertura de vacunación', 'avance': 95},
        {'anio': 2024, 'establecimiento': 'CESFAM Norte', 'meta': 'Control de enfermedades respiratorias', 'avance': 82},
        {'anio': 2024, 'establecimiento': 'CESFAM Sur', 'meta': 'Evaluación nutricional escolar', 'avance': 74},
    ]

    # Calcular estado (verde, amarillo, rojo)
    for d in datos:
        if d['avance'] >= 90:
            d['estado'] = 'verde'
        elif d['avance'] >= 75:
            d['estado'] = 'amarillo'
        else:
            d['estado'] = 'rojo'

    return render(request, 'metas_sanitarias.html', {'metas': datos})


def iaaps(request):
    query = request.GET.get("q")
    datos = IaapsIndicador.objects.all()

    if query:
        datos = datos.filter(
            Q(indicador__icontains=query) | Q(establecimiento__icontains=query)
        ).order_by('anio', 'establecimiento')
    else:
        datos = datos.order_by('anio', 'establecimiento')

    return render(request, 'iaaps.html', {'datos': datos, 'query': query})